export default (name) => console.log(`Hello there, ${name}!`);
